<?php

// src/AppBundle/Controller/LuckyController.php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Response;
use AppBundle\Controller\Main as Main;

class UserController extends Main {

    /**
     * @Route("/user/index")
     */
    public function indexAction() {
        $users = $this->getDoctrine()->getRepository('AppBundle:User')->findAll();

        return $this->render('user/index.html.twig', array(
                    'pagename' => 'asss',
                    'base_dir' => realpath($this->container->getParameter('kernel.root_dir') . '/..'),
        ));
    }

    /**
     * @Route("/user/getusers")
     */
    public function getusersAction() {
        $this->repository = 'AppBundle:Product';
        
        
        $this->addField(array("field" => "ID", "index" => 'id'))
                ->addField(array("field" => "Code", "index" => 'erpCode'))
                ->addField(array("field" => "Code", "index" => 'erpCode'))
                ->addField(array("field" => "Price", "index" => 'itemPricew01'));
        
        $json = $this->getData();
        
        return new Response(
                $json, 200, array('Content-Type' => 'application/json')
        );
    }

}
