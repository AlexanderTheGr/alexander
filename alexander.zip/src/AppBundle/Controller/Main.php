<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;

class Main extends Controller {

    var $fields = array();
    var $repository;

    function __construct() {
        
    }

    public function getData() {
        ini_set("memory_limit", "1256M");






        $repository = $this->getDoctrine()
                ->getRepository($this->repository);

        
        $qb = $repository->createQueryBuilder('p');
        $qb->select('id'); 
        $count = $qb->getQuery()->getSingleScalarResult();
        
        $query = $repository->createQueryBuilder('p')
                ->setMaxResults(1000)
                ->setFirstResult(200)
                ->getQuery();


        $products = $query->getResult();

        $data["fields"] = $this->fields;

        $ia = 0;
        foreach ($products as $user) {
            $json = array();
            foreach ($data["fields"] as $field) {
                $json[] = $user->getField($field["index"]);
            }
            $jsonarr[] = $json;

            if ($ia++ > 100)
                break;
        }
        $data["data"] = $jsonarr;
        $data["recordsTotal"] = 1000;
        $data["recordsFiltered"] = count($jsonarr);
        return json_encode($data);
    }

    function addField($field = array()) {
        $this->fields[] = $field;
        return $this;
    }

}
