<?php

/* user/index.html.twig */
class __TwigTemplate_25d1fce69eda92b5c03e502850e59d429745354889f90b9494f94c463d43d9e4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "user/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dc714a9bf1bb6a650b7cb1066ddcf4707821a5bf071dd58c17a4c105b4c78776 = $this->env->getExtension("native_profiler");
        $__internal_dc714a9bf1bb6a650b7cb1066ddcf4707821a5bf071dd58c17a4c105b4c78776->enter($__internal_dc714a9bf1bb6a650b7cb1066ddcf4707821a5bf071dd58c17a4c105b4c78776_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "user/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_dc714a9bf1bb6a650b7cb1066ddcf4707821a5bf071dd58c17a4c105b4c78776->leave($__internal_dc714a9bf1bb6a650b7cb1066ddcf4707821a5bf071dd58c17a4c105b4c78776_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_da96d7b0b183f3b85b211c70b12d2bc88be0081cf2f069f96f889c3cb03aa8c3 = $this->env->getExtension("native_profiler");
        $__internal_da96d7b0b183f3b85b211c70b12d2bc88be0081cf2f069f96f889c3cb03aa8c3->enter($__internal_da96d7b0b183f3b85b211c70b12d2bc88be0081cf2f069f96f889c3cb03aa8c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div ng-app=\"myApp\" ng-controller=\"customersCtrl\"> 
        <table class=\"table table-striped dataTable\">
            <thead>
                <tr>
                    <td ng-repeat=\"field in fields\">[[ field.field ]]</td>
                </tr>                
            </thead> 
            <tbody>
                <tr ng-repeat=\"record in records\">
                    <td ng-click=\"toggle()\" ng-repeat=\"field in record\">[[ field ]]</td>                   
                </tr>
            </tbody>
        </table>
    </div>
";
        
        $__internal_da96d7b0b183f3b85b211c70b12d2bc88be0081cf2f069f96f889c3cb03aa8c3->leave($__internal_da96d7b0b183f3b85b211c70b12d2bc88be0081cf2f069f96f889c3cb03aa8c3_prof);

    }

    // line 20
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_128c92e57869fef7ad183b19d1b6aada94e7f1fa492240969a4d3c55054c354f = $this->env->getExtension("native_profiler");
        $__internal_128c92e57869fef7ad183b19d1b6aada94e7f1fa492240969a4d3c55054c354f->enter($__internal_128c92e57869fef7ad183b19d1b6aada94e7f1fa492240969a4d3c55054c354f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_128c92e57869fef7ad183b19d1b6aada94e7f1fa492240969a4d3c55054c354f->leave($__internal_128c92e57869fef7ad183b19d1b6aada94e7f1fa492240969a4d3c55054c354f_prof);

    }

    // line 22
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4baea662cd46ee481331dfde73a6436b59add0bb85ff2a9b441cf43742d5690a = $this->env->getExtension("native_profiler");
        $__internal_4baea662cd46ee481331dfde73a6436b59add0bb85ff2a9b441cf43742d5690a->enter($__internal_4baea662cd46ee481331dfde73a6436b59add0bb85ff2a9b441cf43742d5690a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 23
        echo "    <script>
        dataTable(\"customersCtrl\");

        function dataTable(ctrl) {
            var app = angular.module('myApp', ['datatables']).config(function (\$interpolateProvider) {
                \$interpolateProvider.startSymbol('[[').endSymbol(']]');
            });
            var data = {};
            data.id = 1;
            app.controller(ctrl, function (\$scope, \$http) {
                \$http.get(\"/user/getusers\", \"id=1\")
                        .success(function (response) {
                            \$scope.records = response.data;
                            \$scope.fields = response.fields;
                            setTimeout(function () {
                                \$(\".dataTable\").dataTable({
                                    \"processing\": true,
                                    \"serverSide\": true,
                                    \"ajax\": \"/user/getusers\"
                                })
                            }, 1)
                        });
            });
        }
    </script>
";
        
        $__internal_4baea662cd46ee481331dfde73a6436b59add0bb85ff2a9b441cf43742d5690a->leave($__internal_4baea662cd46ee481331dfde73a6436b59add0bb85ff2a9b441cf43742d5690a_prof);

    }

    public function getTemplateName()
    {
        return "user/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  80 => 23,  74 => 22,  63 => 20,  42 => 4,  36 => 3,  11 => 1,);
    }
}
