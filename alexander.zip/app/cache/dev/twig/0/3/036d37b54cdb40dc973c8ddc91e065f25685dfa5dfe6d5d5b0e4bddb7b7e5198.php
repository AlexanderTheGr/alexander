<?php

/* base.html.twig */
class __TwigTemplate_036d37b54cdb40dc973c8ddc91e065f25685dfa5dfe6d5d5b0e4bddb7b7e5198 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13cfdd06f78cb31cc51368378819a183f5748c802cdd36cf97a5307058c973e9 = $this->env->getExtension("native_profiler");
        $__internal_13cfdd06f78cb31cc51368378819a183f5748c802cdd36cf97a5307058c973e9->enter($__internal_13cfdd06f78cb31cc51368378819a183f5748c802cdd36cf97a5307058c973e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head>
        <title>";
        // line 4
        echo twig_escape_filter($this->env, (isset($context["pagename"]) ? $context["pagename"] : $this->getContext($context, "pagename")), "html", null, true);
        echo "</title>

        <!-- BEGIN META -->
        <meta charset=\"utf-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
        <meta name=\"keywords\" content=\"your,keywords\">
        <meta name=\"description\" content=\"Short explanation about this website\">
        <!-- END META -->

        <!-- BEGIN STYLESHEETS -->
        <link href='http://fonts.googleapis.com/css?family=Roboto:300italic,400italic,300,400,500,700,900' rel='stylesheet' type='text/css'/>
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/theme-4/bootstrap.css?1422792965\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/theme-4/materialadmin.css?1425466319\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/theme-4/font-awesome.min.css?1422529194\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/theme-4/material-design-iconic-font.min.css?1421434286\" />
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/theme-4/libs/DataTables/jquery.dataTables.css\">
        <link type=\"text/css\" rel=\"stylesheet\" href=\"/assets/css/main.css\">
        
        ";
        // line 22
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 23
        echo "        <!-- END STYLESHEETS -->

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
        <script type=\"text/javascript\" src=\"//assets/js/libs/utils/html5shiv.js?1403934957\"></script>
        <script type=\"text/javascript\" src=\"//assets/js/libs/utils/respond.min.js?1403934956\"></script>
        <![endif]-->
    </head>
    <body class=\"menubar-hoverable header-fixed \">

        <!-- BEGIN HEADER-->
        <header id=\"header\" >
            <div class=\"headerbar\">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class=\"headerbar-left\">
                    <ul class=\"header-nav header-nav-options\">
                        <li class=\"header-nav-brand\" >
                            <div class=\"brand-holder\">
                                <a href=\"/\" >
                                    <!--span class=\"text-lg text-bold text-primary\">MATERIAL ADMIN</span-->
                                    <img style=\"height: 50px;\" src=\"//assets/img/logo.png\"/>
                                </a>
                            </div>
                        </li>
                        <li>
                            <a class=\"btn btn-icon-toggle menubar-toggle\" data-toggle=\"menubar\" href=\"javascript:void(0);\">
                                <i class=\"fa fa-bars\"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class=\"headerbar-right\">

                    <ul class=\"header-nav header-nav-profile\">
                        <li class=\"dropdown\">
                            <a href=\"javascript:void(0);\" class=\"dropdown-toggle ink-reaction\" data-toggle=\"dropdown\">
                                <img src=\"//assets/img/avatar1.jpg?1403934956\" alt=\"\" />
                                <span class=\"profile-info\">
                                    <?php echo \$this->user->getFirstName() . \" \" . \$this->user->getLastName() ?>
                                    <small><?php echo \$this->userrole; ?></small>
                                </span>
                            </a>
                            <ul class=\"dropdown-menu animation-dock\">
                                <li class=\"dropdown-header\">Config</li>
                                <li><a href=\"/settings\"><i class=\"fa fa-fw fa-cogs\"></i> Settings</a></li>
                                <li><a href=\"/site/logout\"><i class=\"fa fa-fw fa-power-off text-danger\"></i> Logout</a></li>
                            </ul><!--end .dropdown-menu -->
                        </li><!--end .dropdown -->
                    </ul><!--end .header-nav-profile -->
                    <ul class=\"header-nav header-nav-toggle\">
                        <li>
                            <a class=\"btn btn-icon-toggle btn-default\" id=\"offcanvaschat\" href=\"#offcanvas-chat\" data-toggle=\"offcanvas\" data-backdrop=\"false\">
                                <i class=\"fa fa-wechat\"></i>
                            </a>
                        </li>
                    </ul><!--end .header-nav-toggle -->
                </div><!--end #header-navbar-collapse -->
            </div>
        </header>
        <!-- END HEADER-->

        <!-- BEGIN BASE-->
        <div id=\"base\">

            <!-- BEGIN OFFCANVAS LEFT -->
            <div class=\"offcanvas\">
            </div><!--end .offcanvas-->
            <!-- END OFFCANVAS LEFT -->

            <!-- BEGIN CONTENT-->
            <div id=\"content\">
                <section>
                    <div class=\"section-body\">
                        <div class=\"row\">

                            <!-- BEGIN ALERT - REVENUE -->
                            <div class=\"col-md-12 col-sm-6\">
                                <div class=\"card\">
                                    <div class=\"card-head style-primary-light\">
                                        <header>
                                            <i class=\"fa fa-fw fa-tag\"></i>
                                            ";
        // line 105
        echo twig_escape_filter($this->env, (isset($context["pagename"]) ? $context["pagename"] : $this->getContext($context, "pagename")), "html", null, true);
        echo "
                                        </header>
                                    </div>
                                    <div class=\"card-body\">
                                    ";
        // line 109
        $this->displayBlock('body', $context, $blocks);
        // line 110
        echo "                                    </div><!--end .card-body -->
                                </div><!--end .card -->
                            </div><!--end .col -->


                        </div><!--end .row -->

                    </div><!--end .section-body -->
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->

            <!-- BEGIN MENUBAR-->
            <div id=\"menubar\" class=\"menubar-inverse \">
                <div class=\"menubar-fixed-panel\">
                    <div>
                        <a class=\"btn btn-icon-toggle btn-default menubar-toggle\" data-toggle=\"menubar\" href=\"javascript:void(0);\">
                            <i class=\"fa fa-bars\"></i>
                        </a>
                    </div>
                    <div class=\"expanded\">
                        <a href=\"/\">
                            <span class=\"text-lg text-bold text-primary \">MATERIAL&nbsp;ADMIN</span>
                        </a>
                    </div>
                </div>
                <div class=\"menubar-scroll-panel\">

                    <!-- BEGIN MAIN MENU -->
                    <ul id=\"main-menu\" class=\"gui-controls\">


                        <li>
                            <a href=\"/\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"md md-home\"></i></div>
                                <span class=\"title\">Αρχική</span>
                            </a>
                        </li>
                        <li>
                            <a href=\"/users/user\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"md md-person\"></i></div>
                                <span class=\"title\">Χρήστες</span>
                            </a>
                        </li>   
                        <li>
                            <a href=\"/product/product\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"fa fa-gear\"></i></div>
                                <span class=\"title\">Είδη</span>
                            </a>
                        </li>                          
                        <li>
                            <a href=\"/product/supplier\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"md md-computer\"></i></div>
                                <span class=\"title\">Προμηθευτές</span>
                            </a>
                        </li>    
                        <li>
                            <a href=\"/customers/customer\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"md md-people\"></i></div>
                                <span class=\"title\">Πελάτες</span>
                            </a>
                        </li>  
                        <li>
                            <a href=\"/route/route\" class=\"\">
                                <div class=\"gui-icon\"><i class=\"fa fa-truck\"></i></div>
                                <span class=\"title\">Δρομολόγια</span>
                            </a>
                        </li>                          
                        <li class=\"gui-folder\">
                            <a class=\"\">
                                <div class=\"gui-icon\"><i class=\"md md-shopping-cart\"></i></div>
                                <span class=\"title\">Παραγγελίες</span>
                            </a>

                            <!--start submenu -->
                            <ul>
                                <li><a href=\"/orders/order\" ><span class=\"title\">Λίστα Παραγγελιών</span></a></li>
                                <li><a href=\"/orders/order/edit\" ><span class=\"title\">Νέα Πραγγελία</span></a></li>  
                                <li><a href=\"/orders/order/noorder\" ><span class=\"title\">Νέα Προσφορά</span></a></li>  
                            </ul><!--end /submenu -->
                        </li><!--end /menu-li -->
                        <li class=\"gui-folder\">
                            <a href=\"#\">
                                <div class=\"gui-icon\"><i class=\"md md-assessment\"></i></div>
                                <span class=\"title\">Στατιστικά</span>
                            </a>
                            <ul>
                                <li><a href=\"/report/report/sales\" ><span class=\"title\">Πωλήσεις</span></a></li>
                                <li><a href=\"/report/report/search\" ><span class=\"title\">Αναζητήσεις</span></a></li>  
                            </ul><!--end /submenu -->                           
                        </li>
                    </ul><!--end .main-menu -->
                    <!-- END MAIN MENU -->

                    <div class=\"menubar-foot-panel\">
                        <small class=\"no-linebreak hidden-folded\">
                            <span class=\"opacity-75\">Copyright &copy; 2014</span> <strong>CodeCovers</strong>
                        </small>
                    </div>
                </div><!--end .menubar-scroll-panel-->
            </div><!--end #menubar-->
            <!-- END MENUBAR -->

            <button class=\"btn btn-default-bright btn-raised\" data-toggle=\"modal\" style=\"display:none;\" id=\"loadingmodal\" data-target=\"#loading\">loading</button>
            <div class=\"modal fade\" id=\"loading\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"formModalLabel\" aria-hidden=\"true\">
                <div style=\"width:1000px\" class=\"modal-dialog\">
                    <div  style=\"width:1000px\"  class=\"modal-content\">
                        <div class=\"modal-body\">
                            <h2>Please Wait</h2>
                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div>      
            <button class=\"btn btn-default-bright btn-raised\" data-toggle=\"modal\" style=\"display:none;\" id=\"binfomodal\" data-target=\"#infomodal\">loading</button>
            <div class=\"modal fade\" id=\"infomodal\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"formModalLabel\" aria-hidden=\"true\">
                <div class=\"modal-dialog\">
                    <div class=\"modal-content\">
                        <div class=\"modal-body\">

                        </div>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div>                 
            <!-- BEGIN OFFCANVAS RIGHT -->
            <div class=\"offcanvas\">

                <!-- BEGIN OFFCANVAS SEARCH -->
                <div id=\"offcanvas-search\" style='width: 1600px' class=\"offcanvas-pane style-default-light\">
                    <div class=\"offcanvas-head\">
                        <header class=\"text-primary\">Search</header>
                        <div class=\"offcanvas-tools\">
                            <a class=\"btn btn-icon-toggle btn-default-light pull-right\" data-dismiss=\"offcanvas\">
                                <i class=\"md md-close\"></i>
                            </a>
                        </div>
                    </div>
                    <div class=\"offcanvas-body\">

                    </div><!--end .offcanvas-body -->
                </div><!--end .offcanvas-pane -->
                <!-- END OFFCANVAS SEARCH -->

                <div id=\"offcanvas-form\" class=\"offcanvas-pane style-default-light\" style='width:1000px'>
                    <div class=\"offcanvas-head\">
                        <header class=\"text-primary\">Search</header>
                        <div class=\"offcanvas-tools\">

                        </div>
                    </div>                    
                    <div class=\"offcanvas-body\">

                    </div>
                </div>

                <!-- BEGIN OFFCANVAS CHAT -->
                <div id=\"offcanvas-chat\" class=\"offcanvas-pane style-default-light width-12\">
                    <div class=\"offcanvas-head style-default-bright\">
                        <header class=\"text-primary\">Chat</header>
                        <div class=\"offcanvas-tools\">
                            <a class=\"btn btn-icon-toggle btn-default-light pull-right\" data-dismiss=\"offcanvas\">
                                <i class=\"md md-close\"></i>
                            </a>
                            <!--a class=\"btn btn-icon-toggle btn-default-light pull-right\" href=\"#offcanvas-search\" data-toggle=\"offcanvas\" data-backdrop=\"false\">
                                <i class=\"md md-arrow-back\"></i>
                            </a-->
                        </div>
                        <div class=\"form\">
                            <div class=\"form-group floating-label\">
                                <input  name=\"sidebarChatMessage\" id=\"sidebarChatMessage\" maxlength=200 class=\"form-control autosize\" rows=\"1\">
                                <label for=\"sidebarChatMessage\">Leave a message</label>
                            </div>
                        </div>
                    </div>
                    <div  class=\"offcanvas-body\">
                        <ul id=\"chat-area\" class=\"list-chats\">
                        </ul>
                    </div><!--end .offcanvas-body -->
                </div><!--end .offcanvas-pane -->
                <!-- END OFFCANVAS CHAT -->

            </div><!--end .offcanvas-->
            <!-- END OFFCANVAS RIGHT -->

        </div><!--end #base-->
        <!-- END BASE -->        
        <!-- BEGIN JAVASCRIPT -->
        <script src=\"/assets/js/libs/jquery/jquery-1.11.2.min.js\"></script>
        <script src=\"/assets/js/libs/jquery/jquery-migrate-1.2.1.min.js\"></script>
        <script src=\"/assets/js/libs/bootstrap/bootstrap.min.js\"></script>
        <script src=\"/assets/js/libs/spin.js/spin.min.js\"></script>
        <script src=\"/assets/js/libs/autosize/jquery.autosize.min.js\"></script>
        <script src=\"/assets/js/libs/nanoscroller/jquery.nanoscroller.min.js\"></script>
        <script src=\"/assets/js/core/source/App.js\"></script>
        <script src=\"/assets/js/core/source/AppNavigation.js\"></script>
        <script src=\"/assets/js/core/source/AppOffcanvas.js\"></script>
        <script src=\"/assets/js/core/source/AppCard.js\"></script>
        <script src=\"/assets/js/core/source/AppForm.js\"></script>
        <script src=\"/assets/js/core/source/AppNavSearch.js\"></script>
        <script src=\"/assets/js/core/source/AppVendor.js\"></script>
        <script src=\"/assets/js/core/demo/Demo.js\"></script>
        <script src=\"/assets/js/libs/DataTables/jquery.dataTables.min.js\"></script>
        <script src=\"/assets/js/core/source/Angular.js\"></script> 
        <script src=\"/assets/js/core/source/angular-datatables.min.js\"></script> 
        ";
        // line 313
        $this->displayBlock('javascripts', $context, $blocks);
        // line 314
        echo "        <!-- END JAVASCRIPT -->    
    </body>
</html>
";
        
        $__internal_13cfdd06f78cb31cc51368378819a183f5748c802cdd36cf97a5307058c973e9->leave($__internal_13cfdd06f78cb31cc51368378819a183f5748c802cdd36cf97a5307058c973e9_prof);

    }

    // line 22
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_a21e1f466c39c9a8e2dd4781eae9d87d7b51706836e93e61b726a49466305b82 = $this->env->getExtension("native_profiler");
        $__internal_a21e1f466c39c9a8e2dd4781eae9d87d7b51706836e93e61b726a49466305b82->enter($__internal_a21e1f466c39c9a8e2dd4781eae9d87d7b51706836e93e61b726a49466305b82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_a21e1f466c39c9a8e2dd4781eae9d87d7b51706836e93e61b726a49466305b82->leave($__internal_a21e1f466c39c9a8e2dd4781eae9d87d7b51706836e93e61b726a49466305b82_prof);

    }

    // line 109
    public function block_body($context, array $blocks = array())
    {
        $__internal_2313ca0c5bb357b89058da4a24b176e6e8ab07f4f220a9bc9cb0b964b8d84e07 = $this->env->getExtension("native_profiler");
        $__internal_2313ca0c5bb357b89058da4a24b176e6e8ab07f4f220a9bc9cb0b964b8d84e07->enter($__internal_2313ca0c5bb357b89058da4a24b176e6e8ab07f4f220a9bc9cb0b964b8d84e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_2313ca0c5bb357b89058da4a24b176e6e8ab07f4f220a9bc9cb0b964b8d84e07->leave($__internal_2313ca0c5bb357b89058da4a24b176e6e8ab07f4f220a9bc9cb0b964b8d84e07_prof);

    }

    // line 313
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8ac219c0f32e4858fdc20baf75af52c2d430e7a5da2a5c0255ea7c4d49286d79 = $this->env->getExtension("native_profiler");
        $__internal_8ac219c0f32e4858fdc20baf75af52c2d430e7a5da2a5c0255ea7c4d49286d79->enter($__internal_8ac219c0f32e4858fdc20baf75af52c2d430e7a5da2a5c0255ea7c4d49286d79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_8ac219c0f32e4858fdc20baf75af52c2d430e7a5da2a5c0255ea7c4d49286d79->leave($__internal_8ac219c0f32e4858fdc20baf75af52c2d430e7a5da2a5c0255ea7c4d49286d79_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  385 => 313,  374 => 109,  363 => 22,  353 => 314,  351 => 313,  146 => 110,  144 => 109,  137 => 105,  53 => 23,  51 => 22,  30 => 4,  25 => 1,);
    }
}
